select top 2 tipo_empl from empleado;
-- Sirve para limitar la cantidad de filas devueltas en el resultado de una consulta (top n filas)
-- En este caso, se seleccionan solo las primeras 2 filas de la columna tipo_empl de la tabla empleado.

