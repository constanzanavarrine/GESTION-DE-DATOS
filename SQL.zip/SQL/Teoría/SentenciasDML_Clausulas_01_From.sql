FROM 

-- Se utiliza para especificar de que tabla o tablas (o vistas) se van a recuperar datos en una consulta. 