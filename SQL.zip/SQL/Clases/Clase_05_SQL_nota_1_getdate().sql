--- getdate() ---> devuelve un objeto del tipo DateTime 

select GETDATE() Fecha_Hora, CAST( GETDATE() as date) fecha