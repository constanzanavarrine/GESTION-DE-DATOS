WHERE

-- Se utiliza para filtrar registros (filas) en una tabla, devolviendo
-- solo aquellos que cumplen con una condicion especifica.

-- Es una herramienta fundamental para restringir los resultados de una consulta y
-- obtener la informacion relevante de una base de datos.

-- Se utiliza en conjunto con las sentencias SELECT, UPDATE, DELETE, etc.

