select distinct columna1 from tabla_o_vista;
-- Sirve para eliminar filas duplicadas en el resultado de una consulta.
-- En este caso, se seleccionan solo los valores únicos de la columna1 de la tabla


